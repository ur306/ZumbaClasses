package com.caltech.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.caltech.dbUtil.DbUtil;
import com.caltech.pojo.Student;

public class StudentDAO {
public int insertIntodB(Student student) throws ClassNotFoundException, SQLException {
		
		//Register the driver [vendor ],Connection with the dB
		Connection con=DbUtil.getDbConn();
		
		if(con!=null) {
			System.out.println("dB connection established ");
		}
		else {
			System.out.println("connection with dB failed ");
		}
		String sql="insert into student values(?,?,?)";
		
		//Prepare the statement,Execution of the sql ,Close the connection
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,student.getSid());
		ps.setString(2,student.getSname());
		ps.setString(3,student.getSemail());
		//insert,update,delete 
		int row=ps.executeUpdate();
		return row;
		
	}
	
	public List<Student> retrieveStudentData() throws ClassNotFoundException, SQLException {
		
		//Register the driver [vendor ],Connection with the dB
				Connection con=DbUtil.getDbConn();
				
				if(con!=null) {
					System.out.println("dB connection established ");
				}
				else {
					System.out.println("connection with dB failed ");
				}
				//Prepare the statement,Execution of the sql ,Close the connection
				Statement st=con.createStatement();
				
				String sql="select * from student";
				
				ResultSet rs=st.executeQuery(sql);//address of the table 
				
				
//				while(rs.next()) {
//				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
//				}
				
				
				List<Student> list=new ArrayList<>();
				
				while(rs.next()) {
					Student student=new Student();
					student.setSid(rs.getInt("sid"));
					student.setSname(rs.getString("sname"));
					student.setSemail(rs.getString("semail"));
					list.add(student);
				
				}
				
		return list;
		
	}
	
	
	public List<Student> deleteStudentById(int id) throws ClassNotFoundException, SQLException{
		Connection con=DbUtil.getDbConn();
		
		if(con!=null) {
			System.out.println("dB connection established ");
		}
		else {
			System.out.println("connection with dB failed ");
		}
		//Prepare the statement,Execution of the sql ,Close the connection
		String sql="delete from student where sid=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.executeUpdate();
		ps.close();
		return retrieveStudentData();
		
	}
	
	
	public List<Student> updateStudentById(int id,String name) throws ClassNotFoundException, SQLException{
Connection con=DbUtil.getDbConn();
		
		if(con!=null) {
			System.out.println("dB connection established ");
		}
		else {
			System.out.println("connection with dB failed ");
		}
		
		String sql="update student set sname=? where sid=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, name);
		ps.setInt(2, id);
		ps.executeUpdate();
		ps.close();
		return retrieveStudentData();
		
	}
	
	
	
}

